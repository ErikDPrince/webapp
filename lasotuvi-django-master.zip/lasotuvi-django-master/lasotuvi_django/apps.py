from django.apps import AppConfig


class LasotuviDjangoConfig(AppConfig):
    name = 'lasotuvi_django'
